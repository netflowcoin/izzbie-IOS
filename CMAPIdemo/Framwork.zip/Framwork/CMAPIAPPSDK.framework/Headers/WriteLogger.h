//
//  Logger.h
//  CMAPIAPPSDK
//
//  Created by apple on 2019/10/25.
//  Copyright © 2019年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface WriteLogger : NSObject
@property (nonatomic,copy)NSString *logPathStr;

+ (instancetype)sharedInstance;

- (void)writeLog:(NSString *)message;
- (void)writeLogAppendingDate:(NSString *)message;
- (void)writeLogFileForce:(NSString *)message;
- (void)writeLogFile:(NSString *)message force:(BOOL)bforce;

- (void)processMemDict:(NSDictionary *)dic isEnc:(BOOL)bEnc;

@end

NS_ASSUME_NONNULL_END
