//
//  Common.h
//  CMAPIAPPSDK
//
//  Created by apple on 2019/3/26.
//  Copyright © 2019年 apple. All rights reserved.
//

#ifndef Common_h
#define Common_h

typedef enum
{
    AAM_NONE = 0,  //不需要辅助认证
    AAM_SMS = 1,   //使用短信口令进行辅助认证
    AAM_END
} AUX_AUTHENTICATE_MODE;

typedef enum
{
    CE_SUCC = 0,    //成功
    CE_FAIL,    //一般无法定位具体错误原因时返回该值
    CE_SOCKET,        //网络套接字接口操作失败(一般是系统不支持该操作或者进程权限不够导致)
    CE_DISCONNECTED,    //TCP连接中断
    CE_VERSION_DISMATCH,    //版本不匹配
    CE_PROTOCOL,    //协议错误
    CE_TIMEOUT,     //等待超时
    CE_INVALID_USER,    //无效的用户名
    CE_INVLIAD_PASS,    //无效的密码
    CE_MAX_DEVICE,      //虚网网络中设备数量超限
    CE_NO_GATEWAY = 10,     //无可用的虚拟网关
    CE_NO_NETWORK,      //无可用的虚拟网
    CE_DEVICE_NOTEXISTS,        //设备不存在(设备被管理员删除)
    CE_DEVICE_ONLINED,      //设备以及在线
    CE_DEVICE_DISABLED,     //设备被禁用
    CE_USER_UNACTIVE,   //用户未激活
    CE_USER_LOCKED,     //用户被锁定
    CE_INVALID_TUN_DEVICE,      //虚拟网卡设备不可用
    CE_CANCEL,      //用户主动取消操作
    CE_REDIRECT,        //连接被重定向
    CE_AUX_AUTH_DISMATCH = 20,      //认证模式不匹配
    CE_INVALID_PARTNERID,       //无效的合作伙伴ID
    CE_INVALID_APPID,       //无效的app ID
    CE_PENDING,     //正在加载
    CE_STATUS,      //错误的状态(该操作不能在这种状态下进行，如登出状态下获取好友设备信息)
    CE_UNINITIALIZED,       //SDK未成功初始化
    CE_NETWORK_UNREACHABLE,     //本地网络不可用
    CE_INVALID_AUTHORIZATION,       //无效的认证模式
    CE_UNKNOWN_DEVCODE,     //无效的设备类型(只有米米网授权的设备类型才允许登入)
    CE_INVALID_SN,      //无效的设备机器码(只有米米网授权的设备机器码才允许登入)
    CE_NO_SN_SELECTED = 30,     //未选择超级节点(部分操作需要选择超级节点才能进行)
    CE_OPERATION_DENIED,        //操作被拒绝(执行了米米网未授权的操作)
    CE_MEMERY_OUT,      //内存不够，操作失败
    CE_INVALID_SMS,         //短信口令失效，请重新申请
    CE_INVALID_TICKET,      //无效的ticket
    CE_TRY_TOO_MANY_TIMES,      //尝试次数过于频繁
    CE_INVALID_DEIVE_CLASS,     //无效的设备类型
    CE_CALL_THIRD_API_FAIL,     //与第三方接口对接失败(PC端和移动端使用)
    CE_INVALID_CODE,        //无效的第三方code（PC端和移动端使用）
    CE_MODULE_LOST,     //模块丢失（内部错误，一般不对外)
    CE_GW_AUTH_TIMEOUT, //与网关认证超时（内部使用，仅windows平台使用)
    CE_QOS_METER,   //流量限制，报文被丢弃（内部使用，一般不对外)
    CE_PACKAGE_DROP,    //报文被丢弃（内部使用，一般不对外)
    CE_PACKAGE_PROCESSED_BY_OTHER,  //报文被其它模块处理（内部使用，一般不对外)
    CE_AUTHORIZING, //正在审批
    CE_AUTHORIZIE_DENIAL,   //审批未通过
    CE_INVALID_SIGNATURE,   //无效的签名
    CE_OTHER_INSTANCE_LOGIN,    //本系统有其它sdvn实例正在登录
    CE_CORE_TIMEOUT = 1000,     //连接服务进程超时，可能服务进程未被正常启动
    CE_INVALID_PARAMETER = 1001,        //参数错误，如:传入的JSON参数格式不正确
} CN_ERR;
typedef enum
{
    CCS_UNKNOWN = 0, //未知
    CCS_PREPARE,     //已经就绪（内部初始化使用）
    CCS_CONNECTING,  //正在登入
    CCS_CONNECTED,   //登入状态，虚网隧道已激活
    CCS_DISCONNECTED,//登出状态，虚网隧道未激活
    CCS_AUTHTICATED, //认证完成，虚网隧道未激活
    CCS_UNACTIVE, // 设备未激活，用于非终端类型设备
    CCS_ACTIVING, // 设备激活中
    CCS_DISCONNECTING,  // 正在断开连接
    CCS_WAIT_RECONNECTING, //正在等待重连
} CONNECTION_STAT;

typedef enum
{
    DR_UNSET = 0,
    DR_BY_USER,     //1.通过CMD_DISCONNECT登出 2.设备开机，但未设置自动登入
    DR_MISVERSION,      //版本太低(被限制登录)
    DR_NETWORK_TIMEOUT,     //与后台服务器的网络连接中断(如后台升级)
    DR_MISSING_INFO,        //未配置过任何账号信息或者设备账号信息丢失
    DR_INVALID_USER,    //无效的用户名
    DR_INVALID_PASS,    //无效的密码，或者口令
    DR_DEVICE_DELETED,    //设备被管理端删除
    DR_DEVICE_ONLINE,    //已有一台该SN的设备在线
    DR_DEVICE_DISABLED,    //设备被限制登入
    DR_MAX_DEVICE=10,    //设备数量超限
    DR_NO_NETWORK,    //无可用的虚拟网络（一般不会发生）
    DR_KO_USER_REMOVED,    //用户被某个虚拟网络所有者踢出
    DR_KO_DEVICE_REMOVED,    //设备被某个虚拟网络所有者踢出
    DR_KO_DEVICE_DELETED,    //设备被某个虚拟网络所有者踢出
    DR_TUN_DEVICE,    //系统无可用tun设备，或者tun0设备其他程序占用
    DR_DTYPE_CHANGED,    //设备被升级为超级节点(特定设备使用)
    DR_NETWORK_UNUSABLE,    //无可用互联网（如设备网线被拔）
    DR_USER_RELOGIN,    //用户执行了重新登入
    DR_ALGO_TYPE_CHANGED,    //隧道算法被更改
    DR_AUX_AUTH_DISMATCH=20,    //认证模式不匹配
    DR_INVALID_AUTHORIZATION,    //无效的授权
    DR_PROTOCOL,               //协议错误
    DR_NETWORK_BROKEN,         //网络中断
    DR_KICKOUT_BY_AS,          //强制下线
    DR_INVALID_SMS,         //短信口令已过期，需要重新申请短信口令
    DR_INVALID_TICKET,      //无效的ticket
    DR_TRY_TOO_MANY_TIMES,      //登录尝试次数过于频繁
    DR_INVALID_DEVICE_CLASS,
    DR_CALL_THIRD_API_FAIL,     //与第三方接口对接失败
    DR_INVALID_CODE = 30,   //无效的第三方code
    DR_WAKE_UP,     //系统休眠，导致网络中断，从休眠唤醒后将自动重连
    DR_AUTHORIZING, //正在审批
    DR_AUTHORIZIE_DENIAL, //审批未通过
    DR_INVALID_SIGNATURE,   //签名验证失败
    DR_INVALID_TOKEN_TYPE,   //无效的tokentype
    DR_VPN_UNAUTHORIZED=2018,   //VPN未授权
    DR_VPN_SERVER_CONNECT_FAIL=2019,   //VPN服务开启失败
} DISCONNECT_REASON;

typedef enum
{
    AUTH_METHOD_ACCPWD = 0x1, //静态密码登录
    AUTH_METHOD_SMS = 0x2,    //短信口令登录
    AUTH_METHOD_TICKET = 0x3, //ticket登录，多用于短信口令登录后的断线重连，ticket过期或者用户主动登出之后需要重新申请并输入短信口令
    AUTH_METHOD_THIRD_CODE = 0x4,   //第三方code方式认证，code作为uid参数使用
    AUTH_METHOD_PHONE_TOEKN = 0x65, //手机号 + token 实现的一键登录（手机号作为账号，token作为认证数据)
} AUTH_METHOD;

typedef enum{
    RET_SUCCESS = 0,      // 处理成功
    ERR_USER_NOT_EXIST = 101,   // 用户不存在
    ERR_SERVER_ERROR     =  102,   // 服务器内部错误
    ERR_SEND_SMS_FAILED   = 103,    // 发送短信失败
    ERR_NOT_BIND_PHONE    = 104,   // 用户未绑定手机
    ERR_INVALID_REQUEST   = 105,  // 无效请求
    ERR_INVALID_PASSWORD =  106,    // 密码校验错误
    ERR_FREQUENTLY_REQ    = 107,    // 申请过于频繁,稍后再尝试
    ERR_INVALID_PASSWORD_TOO_MUCH = 108,  //密码错误，申请错误超过3次
}RET_SMS_STAT;

typedef NS_ENUM(int, DeviceType)
{
    DT_UNKOWN = 0,
    DT_DEVICE = 1,      //普通设备
    DT_SMARTNODE = 50,      //超级节点设备
    DT_GATEWAY = 100,
};

typedef enum _DEVICE_OS_TYPE {
    DEVICE_OS_TYPE_MACOS = 1,
    DEVICE_OS_TYPE_LINUX = 2,
    DEVICE_OS_TYPE_WINDOWS = 3,
    DEVICE_OS_TYPE_ANDROID = 4,
    DEVICE_OS_TYPE_IOS = 5,
    
    DEVICE_OS_TYPE_ROUTER = 101,
    DEVICE_OS_TYPE_NAS = 102,
    DEVICE_OS_TYPE_CAMERA = 103,
    DEVICE_OS_TYPE_SN = 104,
    DEVICE_OS_TYPE_OPENWRT = 105,
    
} DEVICE_OS_TYPE;


#define IsNSStringEmpty(a) (!a || [a isEqualToString:@""])
#define LogStr(fmt) [NSString stringWithFormat:@"{sdvn} (%s:%d) %@",REMOVEDIR(__FILE__), __LINE__, fmt]

#endif /* Common_h */
