//
//  cmapiApp.h
//  CMAPIAPPSDK
//
//  Created by apple on 2018/9/11.
//  Copyright © 2018年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CMAPIAPPSDK.h"
#import"Common.h"

#define LOCALIZESTRING(x) NSLocalizedStringFromTable(x, @"localizedString", nil)



@protocol CmapiAppNotifyDelegate <NSObject>
@optional

/* CONNECTION_STAT值：
 CCS_UNKNOWN = 0, //未知
 CCS_PREPARE,     //已经就绪（内部初始化使用）
 CCS_CONNECTING,  //正在登入
 CCS_CONNECTED,   //登入状态，虚网隧道已激活
 CCS_DISCONNECTED,//登出状态，虚网隧道未激活
 CCS_AUTHTICATED, //认证完成，虚网隧道未激活
 CCS_UNACTIVE, // 设备未激活，用于非终端类型设备
 CCS_ACTIVING, // 设备激活中
 CCS_DISCONNECTING,  // 正在断开连接
 CCS_WAIT_RECONNECTING, //正在等待重连
 */

/* 连接状态变更代理方法
 * status：变化后的状态 dr：DISCONNECT_REASON类型，只有status为CCS_DISCONNECTED时有值
 */
- (void) statusChange:(CONNECTION_STAT)status Dr:(int)dr;

/* 好友设备状态信息变更的代理方法
 * deviceInfoDic：
 * {
 "status": "online" | "offline | DLT"
 "device_type": DT_DEVICE |DT_SMARTNODE | DT_GATEWAY
 "id": "xx", // Id
 "owner": "xxx", // 设备属主帐号, smartnode or device
 "userid": "xxx", // User Id, smartnode or device
 "domain": "xxx", // 设备域名
 "ad_domain": "xxx", // 设备AD域名, device
 "name": "xx", // 设备名称
 "device_class": xxx, // 设备类型, smartnode or device
 "vip": "x.x.x.x",
 "pubip": "x.x.x.x", // smartnode or device
 "privip": "x.x.x.x", // smartnode or device
 "ver": "x.x.x.x" // smartnode or device
 "feature": xx,   //属性值
 "dlt": {  // DLT 信息
 "class": xx,  // CM_DLT_CLASS
 "peer_ip": "x.x.x.x",
 "peer_port": xx
 },
 "subnet": [  // smartnode or gateway
 { "net": "x.x.x.x", "mask": "x.x.x.x" }
 ]
 }
 */
- (void) deviceChangeNotify:(NSDictionary *)deviceInfoDic;

/* 网络切换完成事件的代理方法
 * errorCode : 0表示为切换成功，否则表示为错误代码
 */
- (void)switchNetworkCompleteNotify:(int)errorCode;

//版本更新事件的代理方法
-(void)updateNotify;

//虚拟网网络变更代理方法
- (void) networkChangeNotify;

//执行命令结果通知代理方法
- (void)applyCommandNotify:(NSDictionary *)messageDic;

/*连接异常的通知代理方法
*return dic :
     "message": {
         "reason": xx,
     }
* reason说明
     DR_NETWORK_TIMEOUT    与后台网络连接超时
     DR_NETWORK_BROKEN    网络不可达
*/
- (void)connectException:(NSDictionary *)dic;

@end

@interface cmapiApp : NSObject

//设置Provider bundle ID
@property (nonatomic ,strong) NSString * kProviderBundleid;
//设置服务器地址
@property (nonatomic ,strong) NSString * kServerAddr;
//设置VPNid
@property (nonatomic ,strong) NSString * kVPNId;
@property (nonatomic ,assign) id statusDelegate;
@property (nonatomic ,assign) id deviceChangeDelegate;
@property (nonatomic ,assign) id switchCompleteDelegate;
@property (nonatomic ,assign) id updateDelegate;
@property (nonatomic ,assign) id networkChangeDelegate;
@property (nonatomic ,assign) id applyCommandDelegate;
@property (nonatomic ,assign) id connectExceptionDelegate;

//单例初始化
+ (instancetype)sharedInstance;

/*
 * 设置日志文件存放路径
 * path ： 存放路径
 * 注意：
 * 请初始化后设置
 */
- (void)setLogPath:(NSString *)path;

/*检测系统vpn是否已被其它应用连接：建议在createSessionWithCompletionHandler和login之前，先执行此方法，当收到completionHandler返回值之后，如果返回NO，再执行createSessionWithCompletionHandler或login，如果返回YES，则不再创建VPN，且不能login
 * result： YES（表示系统VPN已连接） NO（表示系统VPN未连接）
 */
- (void)CheckOtherVPNIsConnected:(void (^)(BOOL result)) completionHandler;

/* 检测VPN服务是否已配置
 * result： YES（表示当前VPN已配置） NO（表示当前VPN未配置）
 * 此方法需要在设置了kVPNId之后才可使用
 */
- (void)checkVPNServiceIsConfiguration:(void (^)(BOOL result)) completionHandler;


/* 创建连接会话并获取是否授权
 * result : YES表示用户已授权开启网络扩展服务，NO表示未授权
 * 注意：
 * 此操作是在未登录状态为CCS_DISCONNECTED执行
 */
- (void) createSessionWithCompletionHandler:(void (^)(BOOL result)) completionHandler;

/* 获取验证码
 * account : 登录的用户名
 * host ：短信服务接口的地址
 * port ：短信服务接口的端口
 * authmode ：短信服务接口的认证模式
 * return RET_SMS_STAT : 返回接口处理结果
 */
- (RET_SMS_STAT)getCodeWithAccount:(NSString *)account withHost:(NSString *)host withPort:(NSString *)port withAuthmode:(int)authmode;

/*DNS过滤设置
* nagation：false就是规则匹配上的走虚拟网DNS解析，未匹配上的走真实DNS解析
            true 就是规则匹配上的走真实DNS解析，未匹配上的走虚拟网DNS解析
* items：需过渡的域名，如：@["*.cmhk.com"]
* 注意：
* 此操作是在未登录状态CCS_DISCONNECTED执行
*/
- (void)setPacOptionNagation:(BOOL)nagation items:(NSArray *)items;

/* 登录
 * account : 用户名
 * password ： 密码
 * auth_data : 使用手机号作为账号，auth_data作为token实现一键登录（无则传空）
 * thirdCode ：第三方认证使用的code，代替账号密码使用（无则传空）
 * auxAuthMode ： 辅助验证模式（AAM_NONE：不需要辅助验证，AAM_SMS：使用短信口令进行辅助验证）
 * auxAuthValue ： 短信验证码（无则传空）
 * authMethod: 认证模式
 * 注意：此操作是在createSessionWithCompletionHandler之后，并在登录状态为CCS_DISCONNECTED时执行
 */
- (void) loginWithAccount:(NSString *)account password:(NSString *)password auth_data:(NSString *)auth_data thirdCode:(NSString *)thirdCode auxAuthMode:(AUX_AUTHENTICATE_MODE)auxAuthMode auxAuthValue:(NSString *)auxAuthValue authMethod:(AUTH_METHOD)authMethod;

/* 短信口令登录
 * account：账号
 * smsCode：短信口令
 */
- (void)loginBySmsWithAccount:(NSString *)account smsCode:(NSString *)smsCode;

/* 登录（静态密码登录方式）
 * account : 用户名
 * password ： 密码
 * 注意：此操作是在createSessionWithCompletionHandler之后，并在登录状态为CCS_DISCONNECTED时执行
 */
- (void) loginWithAccount:(NSString *)account password:(NSString *)password;

/* 登录（使用token实现一键登录）
* account : 手机号
* token ： token实现一键登录
* 注意：此操作是在createSessionWithCompletionHandler之后，并在登录状态为CCS_DISCONNECTED时执行
*/
- (void)loginByTokenWithAccount:(NSString *)account token:(NSString *)token tokenType:(NSString *)tokenType;

/* 登录（只显示vpn图标）
 */
- (void)fakeLogin;

/* 取消正在进行连接或停止已经连接的登录操作
 */
- (void)stopLogin;

/*  合作商账号验证
 *  generateDomain : 生成Token的域名
 *  verifyDomain : 验证Token的域名
 *  appkey : 申请的appKey
 *  eAppid : 申请的eAPPID
 *  appid : 申请的appid
 *  partnerid ：申请的partnerid
 *  return dict :
     {
         "result":0,
         "errmsg":"success",
         "data":{
             "userid":1234,
             "firstname":"张山",
             "lastname":"test",
             "loginname":"test123",
             "phone":"15242457848",
             "email":"15242457848",
              "createdate":"2017-03-31 12:44:21"
         }
     }
 */
- (void)verifyPartnerAccountWithGenerateDomain:(NSString *)generateDomain verifyDomian:(NSString *)verifyDomain appKey:(NSString *)appkey eAppid:(NSString *)eAppid appid:(NSString *)appid partnerid:(NSString *)partnerid completion:(void (^)(NSDictionary *dict,NSError *error)) completion;

/*获取当前VPN连接状态
 *返回值（CONNECTION_STAT）：VPN连接状态值
 *注意：此接口需在createSessionWithCompletionHandler后使用
 */
- (CONNECTION_STAT)getCurrentStatus;

/* 获取基本信息
 * completion     为nil时，方法同步，通过方法返回值返回设备信息；非nil时，方法异步，通过block返回设备信息
 * return NSDictionary :
 * {
 "result": CE_SUCC,       //返回结果
 "users": [              // 曾经成功登录过的账号列表 (所有状态有值)
 {
 "account": "xxx" }  // 账号
 ],
 "information": {
 "version": "x.x.x.x",  // 当前版本 (所有状态有值)
 "status": CCS_XXX,  // 当前状态(所有状态有值)，参见上面的CM_CONNECTION_STAT定义
 "disconnect_reason": xxx,   // 连接断开原因(CCS_DISCONNECTED状态有值)，参见上面的DISCONNECT_REASON定义
 "account" : "xxx",  // 最后一次成功登录的账号 (所有状态有值，为登录过任何账号时为空)
 "uid": "xxx",       // 账号对应的用户唯一编号 (CCS_CONNECTED状态有值)
 "device_id": "xxx",  // 当前设备的唯一编号 (成功登录后，所有状态有值)
 "domain" : "xxx",    // 当前设备的虚拟域名 (CCS_CONNECTED状态有值)
 "ad_domain"; "xxx",  // 当前设备的虚拟AD域名 (CCS_CONNECTED状态有值)
 "vip" : "x.x.x.x",    // 当前的虚拟IP (CCS_CONNECTED状态有值)
 "vmask" : "x.x.x.x",  // 虚拟掩码 (CCS_CONNECTED状态有值)
 "priv_ip": "x.x.x.x",  // 设备的内网地址 (CCS_CONNECTED状态有值)
 "priv_port": xxx,      // 内网私有端口  (CCS_CONNECTED状态有值)
 "timestamp" : xxx,  // 建立连接时的时间戳 (CCS_CONNECTED状态有值)
 "ticket" : "xxx",   // 当前登录的票据 (CCS_CONNECTED状态有值)
 "netid" : "xxx",    // 当前所在网络的Id (CCS_CONNECTED状态有值)
 "snid" : "xxx",       //当前选择的SN Id (CCS_CONNECTED状态有值)
 "as_host" : "xxxx"   //AS域名(所有状态有值)
 },
 "option" : {
 "autologin" : true | false,    // 程序启动时，自动登录 (所有状态有值)
 "dlt": true | false,  // DLT设置 (所有状态有值)
 "st": true | false, // ST设置 (所有状态有值)
 "snmode": true | false  // 设备当前是否为SN (CCS_CONNECTED状态有值)
 "vip_feature": xxx, // VIP_FEATURE 组合值
 "algo_level": xxx,  // 算法等级设置 (所有状态有值)
 "partner_feature": xxx, // 内部使用
 }
 "api_gw_info": {  //应用网关域名
 "domain": "xxxx"
 }
 }
 */
- (NSDictionary *)getBaseInfo:(void (^)(NSDictionary *result)) completion;

/* 删除历史账号
 * acc : 要删除的账号名
 * return BOOL :是否删除成功 true：成功； false：失败
 * 注意：
 * 1､只有在登录状态为CCS_DISCONNECTED时有效
 * 2､删除某个账号后，与这个账号相关的所有本地配置信息都会被删除(如:ST开关状态，DLT开关，选择的超级节点ID等)
 */
- (void)removeUser:(NSString *)acc completion:(void (^)(BOOL result)) completion;

/* 获取虚拟网络登录状态信息
 * completion     为nil时，方法同步，通过方法返回值返回设备信息；非nil时，方法异步，通过block返回设备信息
 * return NSDictionary:
 * {
 "result": CE_SUCC,   //返回结果
 "status": CCS_XXX,  // 当前登录状态，定义见CM_CONNECTION_STAT
 "disconnect_reason": xxx,   // 连接断开原因 (CCS_DISCONNECTED状态有值)，定义见DISCONNECT_REASON
 "data": {
 "duration": xx,       // seconds from established(登录时长)
 "network_status": {   // if CCS_CONNECTED
 "rx_bytes": "xxxx", // uint64 converted to string
 "rx_speed": xxx,    // uint rx speed (bytes)
 "tx_bytes": "xxxx", // uint64 converted to string
 "tx_speed": xxx,    // uint tx speed (bytes)
 "latency" : xxx     // 网络延时 单位 ms
 }
 }
 * 注意：此接口一般用于登入成功之后获取虚拟隧道延时、速度、流量等信息用
 */
- (NSDictionary *)getStatusInfo:(void (^)(NSDictionary * result)) completion;

/* 获取网络信息列表
 * completion     为nil时，方法同步，通过方法返回值返回设备信息；非nil时，方法异步，通过block返回设备信息
 * return NSDictionary :
 * {
 "result" : CE_SUCC,
 "netid": "xxx",    //当前的网络
 "data" : [
 {
 "id" : "xxx",    //网络 ID
 "name" : "xxx",  //网络名称
 "owner" : "xxx"  //网络属主帐号
 }
 ]
 }
 * 注意：此接口在登录状态为CCS_CONNECTED时才有效
 */
- (NSDictionary *)getNetworkList:(void (^)(NSDictionary * result)) completion;

/* 获取当前网络所有设备的列表
 * completion     为nil时，方法同步，通过方法返回值返回设备信息；非nil时，方法异步，通过block返回设备信息
 * return NSDictionary:
 * {
     result = CE_SUCC;
     "devices": [  // 设备列表
         {
             "id": "xx", // Id
             "owner": "xxx", // 设备属主帐号
             "userid": "xxx", // User Id
             "domain": "xxx", // 设备域名
             "ad_domain": "xxx", // 设备AD域名
             "name": "xx", // 设备名称
             "device_class": xxx, // 设备类型
             "vip": "x.x.x.x",
             "privip": "x.x.x.x",
             "pubip": "x.x.x.x",
             "ver": "x.x.x.x",
             "feature": xx,
             "dlt": {
                 "dlt_status": true|false,  //dlt 开关
                 "algo_level": xx,          //隧道算法，参见算法定义
                 "class": xx,
                 "peer_ip": "x.x.x.x",
                 "peer_port": xx
             }
             "subnet": [
                 { "net": "x.x.x.x", "mask": "x.x.x.x" }
             ]
         }
     ]
 }
 * 注意：此接口在登录状态为CCS_CONNECTED时才有效
 */
- (NSDictionary *)getDeviceList:(void (^)(NSDictionary * result)) completion;

/* 根据设备id来获取设备信息，只返回一个设备
 * completion     为nil时，方法同步，通过方法返回值返回设备信息；非nil时，方法异步，通过block返回设备信息
 * idStr ： 设备id
 * return NSDictionary ：同getDeviceList
 * 注意：此接口在登录状态为CCS_CONNECTED时才有效
 */
- (NSDictionary *)getDeviceByID:(NSString *)idStr completion:(void (^)(NSDictionary * result)) completion;

/* 根据设备vip来获取设备信息，只返回一个设备
 * completion     为nil时，方法同步，通过方法返回值返回设备信息；非nil时，方法异步，通过block返回设备信息
 * ipStr ： 设备vip
 * return NSDictionary ：同getDeviceList
 * 注意：此接口在登录状态为CCS_CONNECTED时才有效
 */
- (NSDictionary *)getDeviceByIP:(NSString *)ipStr completion:(void (^)(NSDictionary * result)) completion;

/* 切换网络
 * operatorId：期望切换到的网络id
 * 注意：
 * 1､此接口在登录状态为CCS_CONNECTED时才有效
 * 2､网络是否切换成功，会通过switchCompleteNotify代理方法通知
 */
- (NSDictionary *)switchNetwork:(NSString *)operatorId completion:(void (^)(NSDictionary * result)) completion;

/* 选择smartnode
 * completion     为nil时，方法同步，通过方法返回值返回设备信息；非nil时，方法异步，通过block返回设备信息
 * SmartNodeID：期望切换到的SmartNodeID
 * return BOOL: 是否切换成功 true：成功； false：失败
 * 注意：
 * 1､此接口在登录状态为CCS_CONNECTED时才有效
 * 2､SmartNodeID如果为空，则表示为取消选择
 */
- (BOOL)selectSmartNode:(NSString *)SmartNodeID completion:(void (^)(BOOL result)) completion;

/* 获取流量历史记录
 * completion     为nil时，方法同步，通过方法返回值返回设备信息；非nil时，方法异步，通过block返回设备信息
 * return NSDictionary:
 *{
    "rx" : [xxx,xxxx,xxx...],
    "tx" : [xxx,xxxx,xxx...],
    "delay" : [xxx,xxx,xxx...]
 }
 */
- (NSDictionary *)getHistory:(void (^)(NSDictionary *result)) completion;

/*是否可以更改DLT设置
* return: BOOL YES可以更改  NO不能更改
*/
- (BOOL)isGlobalDltEnabel;

/*当前DLT
* return: BOOL YES已开启  NO已关闭
*/
- (BOOL)isGlobalDlt;


/*是否启用DLT（默认开启）
 * completion     为nil时，方法同步，通过方法返回值返回设备信息；非nil时，方法异步，通过block返回设备信息
 * enabled： YES表示开启，NO表示关闭
 * return: BOOL YES设置成功  NO设置失败
 */
- (BOOL) enableDLT:(BOOL)enabled completion:(void (^)(BOOL result)) completion;

/* 设置重连的次数
 * count ：登录的重试次数，默认为0，会一直重试，每次重试间隔时间增加2秒(初始时间为1秒，即1,3,5,7...)
 * 注意：
 * 此操作是在未登录状态CCS_DISCONNECTED执行
 * 且方法如果不需要修改重试次数值，设置一次即可
 */
- (void)setLoginRetryCount:(NSInteger)count;



@end
