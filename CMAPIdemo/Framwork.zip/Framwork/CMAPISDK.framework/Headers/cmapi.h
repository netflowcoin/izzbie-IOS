//
//  cmapi.h
//  CMAPITUNNEL
//
//  Created by L-wh on 2017/11/28.
//  Copyright © 2017年 L-wh. All rights reserved.
//

#import <Foundation/Foundation.h>

#ifndef cmapi_h
#define cmapi_h
@import NetworkExtension;
@interface cmapi : NSObject

/* 初始化
 * appId : 产品ID，针对每一款产品授权分配
 * partnerID : 合作伙伴ID，由Memenet后台统一授权分配
 * devClass : 设备类型编码，用于区分同一个产品ID下的多个类型的设备
 * dnsDivert : 如果使用虚拟网络的域名，则需要设置DNS,否则反之
 * provider : NEPacketTunnelProvider
 */
-(id) initLibraryWithAppID:(NSString *)appId withPartnerID:(NSString *)partnerID withDevClass:(NSInteger)devClass AndProvider:(NEPacketTunnelProvider *)provider AndDnsDivert:(BOOL)dnsDivert;

//tunnel与服务器数据交互
- (void) processAppMessage:(NSData *)data completion:(void (^)(NSData *))completionHandler;

//开始连接
- (void)startConnectionWithOptions:(NSDictionary *)options completionHandler:(void (^)(NSError *  error))completionHandler;

//开始连接（只显示VPN图标，其它数据都没有）
//使用条件：在provider中的- (void)startTunnelWithOptions:(NSDictionary *)options completionHandler:(void (^)(NSError *))completionHandler方法中，根据需要调用
- (void)fakeConnectionWithCompletionhandler:(void (^)(NSError *  error))completionHandler;

//停止通道连接
-(void)stopTunnel:(void (^)(void))completionHandler;

/*DNS过滤设置
* nagation：false就是规则匹配上的走虚拟网DNS解析，未匹配上的走真实DNS解析
            true 就是规则匹配上的走真实DNS解析，未匹配上的走虚拟网DNS解析
* items：需过渡的域名，如：@["*.cmhk.com"]，如果items为空请不要调用此接口
*/
- (void)setPacOptionNagation:(BOOL)nagation items:(NSArray *)items;

/*设置AS地址和端口
 * asHost：AS地址
 * asPort：AS端口
 */
- (void)setAsHost:(NSString *)asHost withAsPort:(unsigned short)asPort;

//此接口要在initLibraryWithAppID之后调用
-(void)setOutputLogLevel:(int)logLevel;
@end
#endif /* cmapi_h */
